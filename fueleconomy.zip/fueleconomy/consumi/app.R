#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)

marche = list()
vd = veicoli%>%
  group_by(make)%>%
  summarise(c=n())%>%
  filter(c>10)%>%
  pull(make)
vd
for(i in 1:length(vd)){
  marche[[i]]<-vd[i]
}
marche[[length(vd)+1]]<-"tutte"
# Define UI for application that draws a histogram
ui <- fluidPage(
  
  # Application title
  titlePanel("FUELECONOMY"),
  
  # Sidebar with a slider input for number of bins 
  sidebarLayout(
    sidebarPanel(
      sliderInput("year",
                  "Year:",
                  min = 1987,
                  max = 2023,
                  value = 2022),
      
      sliderInput("fuelcost",
                  "FuelCost minimo:",
                  min = 400,
                  max = 12400,
                  step=100,
                  value = 400),
      
      selectInput("marca","marca",
                  choices = marche,
                  selected = "All"),
      #X input
      radioButtons("xaxis",
                   "Asse x",
                   choices = list("annual fuel cost"="fuelCost08",
                                  "cilindrata (l)"="displ"),
                   selected = "fuelCost08"
      ),
      
      #Y input
      radioButtons("yaxis",
                   "Asse y",
                   choices = list("annual fuel cost"="fuelCost08",
                                  "cilindrata (l)"="displ"),
                   selected = "displ"
      )
    ),
    
    # Show a plot of the generated distribution
    mainPanel(
      plotOutput("scatterPlot")
    )
  )
)

# Define server logic required to draw a histogram
server <- function(input, output) {
  
  output$scatterPlot <- renderPlot({
    if(input$marca == "tutte"){
      db<-veicoli%>%
        filter(year < input$year & fuelCost08 > input$fuelcost)%>%
        group_by(model)%>%
        summarise(c=n(),fuelCost08=mean(fuelCost08),displ,atvType)
    }else{
      db<-veicoli%>%
        filter(year < input$year & make == input$marca & fuelCost08 > input$fuelcost)%>%
        group_by(model)%>%
        summarise(c=n(),fuelCost08=mean(fuelCost08),displ,atvType)}
    
    #disegnamo il grafico 
    ggplot(db, aes_string(input$xaxis,input$yaxis,color="atvType"))+geom_point(alpha=0.8,size=6)+
      geom_smooth()+
      theme(axis.text = element_text(color = "blue", size = 18))+
      theme(axis.title = element_text(size = 20))+labs(title = "COSTO ANNUALE CARBURANTE PER CILINDRATA
                                                       ",caption = "Data from fueleconomy.gov")+
      theme(plot.title = element_text(size = 24, color="#428bca"), plot.caption = element_text(size=12))
    
  })
}

# Run the application 
shinyApp(ui = ui, server = server)